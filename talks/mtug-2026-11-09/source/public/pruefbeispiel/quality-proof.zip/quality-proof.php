<?php

/*
 * Offline presentation example for nr-llm's strict schema validator.
 * SPDX-License-Identifier: GPL-2.0-or-later
 * Bundled original validator: Copyright (c) 2025-2026 Netresearch DTT GmbH.
 */

declare(strict_types=1);

use Netresearch\NrLlm\Service\Schema\JsonSchemaValidator;

if (PHP_VERSION_ID < 80200 || !extension_loaded('mbstring')) {
    fwrite(STDERR, "Requires PHP 8.2+ with mbstring. No Composer, TYPO3, API key or network needed.\n");
    exit(2);
}

mb_internal_encoding('UTF-8');
$sourceDirectory = __DIR__ . '/quality-proof-source';
$source = json_decode(file_get_contents($sourceDirectory . '/source.json'), true, 512, JSON_THROW_ON_ERROR);
foreach ($source['files'] as $file) {
    if (hash_file('sha256', $sourceDirectory . '/' . $file['path']) !== $file['sha256']) {
        fwrite(STDERR, 'Original source checksum mismatch: ' . $file['path'] . "\n");
        exit(2);
    }
}

require_once $sourceDirectory . '/Classes/Service/Schema/StrictSchemaSubset.php';
require_once $sourceDirectory . '/Classes/Service/Schema/JsonSchemaValidator.php';

$validator = new JsonSchemaValidator();
$schema = [
    'type' => 'object',
    'required' => ['status', 'description'],
    'additionalProperties' => false,
    'properties' => [
        'status' => ['type' => 'string', 'enum' => ['entwurf', 'pruefung']],
        'description' => ['type' => 'string', 'minLength' => 1, 'maxLength' => 160],
    ],
];
$schemaJson = json_encode($schema, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
$supported = $validator->supportsSchema($schema);

$cases = [
    [
        'id' => 'valid_draft',
        'label' => 'Gültiger Entwurf',
        'input' => ['status' => 'entwurf', 'description' => 'Diskutiert mit uns, wie KI in TYPO3 eingesetzt werden kann.'],
        'expectedValid' => true,
        'interpretation' => 'Status und Textlänge erfüllen die angegebenen Regeln.',
    ],
    [
        'id' => 'invalid_status',
        'label' => 'Nicht erlaubter Status',
        'input' => ['status' => 'veroeffentlicht', 'description' => 'Diskutiert mit uns, wie KI in TYPO3 eingesetzt werden kann.'],
        'expectedValid' => false,
        'interpretation' => 'Der Status ist nicht in der erlaubten Wertemenge enthalten.',
    ],
    [
        'id' => 'description_too_long',
        'label' => '161 statt höchstens 160 Zeichen',
        'input' => ['status' => 'entwurf', 'description' => str_repeat('A', 161)],
        'expectedValid' => false,
        'interpretation' => 'Die Beschreibung überschreitet die angegebene Maximallänge.',
    ],
    [
        'id' => 'unsupported_deadline',
        'label' => 'Formal gültig, Frist unbelegt',
        'input' => ['status' => 'entwurf', 'description' => 'Meldet euch bis 4. November zum TYPO3-Abend an.'],
        'expectedValid' => true,
        'interpretation' => 'Das Schema akzeptiert den Text. Das Briefing belegt den 4. November nicht; ein Quellenvergleich findet in dieser Prüfung nicht statt.',
    ],
];

$allExpectedResults = $supported;
foreach ($cases as &$case) {
    $case['inputJson'] = json_encode($case['input'], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    $case['descriptionLength'] = mb_strlen($case['input']['description']);
    // This is the ORIGINAL PHP implementation, not a replacement validator.
    $case['actualValid'] = $validator->validateJsonStrict($case['inputJson'], $schemaJson);
    $case['matchesExpected'] = $case['actualValid'] === $case['expectedValid'];
    $allExpectedResults = $allExpectedResults && $case['matchesExpected'];
    fwrite(STDERR, sprintf(
        "%s | %s | validateJsonStrict=%s | %d Zeichen\n",
        $case['matchesExpected'] ? 'PASS' : 'FAIL',
        $case['id'],
        $case['actualValid'] ? 'true' : 'false',
        $case['descriptionLength'],
    ));
}
unset($case);

$proof = [
    'title' => 'Formale Regeln prüfen – Aussagen belegen',
    'source' => $source,
    'runtime' => ['phpVersion' => PHP_VERSION, 'mbstring' => true, 'encoding' => mb_internal_encoding()],
    'scope' => [
        'executed' => 'Unveränderte lokale PHP-Schema-Prüfung aus nr-llm ' . $source['version'] . '.',
        'api' => 'JsonSchemaValidator::supportsSchema() + JsonSchemaValidator::validateJsonStrict()',
        'modelCalls' => 0,
        'networkCalls' => 0,
        'backendChanges' => 0,
        'notDemonstrated' => [
            'Modellgenerierung, Providerverhalten oder Reparaturversuch in completeStructured().',
            'Automatische Faktenprüfung, Warnmeldung oder Freigabe im TYPO3-Backend.',
        ],
        'internalApi' => 'Die hier direkt aufgerufenen Klassen sind als @internal markiert. Für Extensions ist die öffentliche CompletionService-API vorgesehen.',
        'interpretationFields' => 'Die Erläuterungen sind Teil des Vortragsbeispiels. Der Validator liefert einen booleschen Wert, keine Fehlerdiagnose in Prosa.',
    ],
    'briefing' => [
        'text' => 'Wir laden zu einem TYPO3-Abend über KI ein. Ein Anmeldeschluss steht noch nicht fest.',
        'passedToValidator' => false,
        'explanation' => 'Dieses Briefing macht die unbelegte Ergänzung sichtbar. Es ist kein Bestandteil des Schemas und wird vom Validator nicht inhaltlich ausgewertet.',
    ],
    'schema' => $schema,
    'schemaSupported' => $supported,
    'cases' => $cases,
    'allExpectedResults' => $allExpectedResults,
    'semanticReview' => [
        'service' => 'DecisionServiceInterface',
        'availableSince' => '0.39.0',
        'executed' => false,
        'status' => 'not_performed',
        'question' => 'Ist die Anmeldefrist 4. November durch das mitgegebene Briefing belegt?',
        'subject' => [
            'task' => 'Verfasse eine kurze Einladung auf Basis des Briefings. Ergänze keine neuen Fakten.',
            'candidate' => 'Meldet euch bis 4. November zum TYPO3-Abend an.',
            'evidence' => 'Wir laden zu einem TYPO3-Abend über KI ein. Ein Anmeldeschluss steht noch nicht fest.',
        ],
        'explanation' => 'nr-llm bietet einen zusätzlichen modellgestützten Quellenabgleich. Die Anwendung muss ihn mit einem Prüfprofil ausdrücklich aufrufen und die Folgen festlegen. Hier wurde kein solcher Modellaufruf ausgeführt; es liegt kein automatisches Urteil zur Frist vor.',
        'documentation' => 'https://github.com/netresearch/t3x-nr-llm/blob/' . $source['commit'] . '/Documentation/Api/DecisionService.rst',
    ],
    'conclusion' => 'Die gelieferten formalen Regeln werden geprüft. Ein passendes Schema belegt nicht die Wahrheit einer frei formulierten Aussage.',
];

echo json_encode($proof, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR), "\n";
fwrite(STDERR, $allExpectedResults ? "All 4 expected results confirmed.\n" : "Unexpected validation result.\n");
exit($allExpectedResults ? 0 : 1);
