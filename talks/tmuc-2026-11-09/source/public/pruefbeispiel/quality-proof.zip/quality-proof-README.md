# Was diese Prüfung zeigt

**nr-llm prüft vorgegebene formale Regeln. Die Wahrheit eines frei formulierten Textes folgt daraus nicht.**

Dieses Beispiel führt den originalen strikten Schema-Validator aus **nr-llm 0.35.0** direkt in PHP aus. Die beiden mitgelieferten Klassen sind unverändert aus Commit `6afad3444ceb0ef3f206f6687df8d23eb881f496` übernommen. Die Dateien wurden beim Erstellen byteweise mit diesem Git-Objekt verglichen; ihre SHA-256-Prüfsummen stehen in `quality-proof-source/source.json` und werden vor jeder Ausführung kontrolliert.

## Wiederholen

Voraussetzung: PHP 8.2 oder neuer mit `mbstring`. Alle Dateien dieses Beispiels im selben Ordner belassen.

```sh
php quality-proof.php > quality-proof.json
```

Das Skript benötigt weder Composer noch TYPO3, Zugangsdaten oder Netzwerk. Es ruft kein Modell auf und verändert kein Backend. Die JSON-Ausgabe enthält Schema, Eingaben und tatsächliche Rückgabewerte; die kurze Zusammenfassung erscheint auf STDERR. Exit-Code 0 bedeutet, dass alle vier erwarteten Ergebnisse bestätigt wurden. Bei einem unerwarteten Prüfergebnis liefert das Skript Exit-Code 1; fehlen Voraussetzungen oder stimmen die Quelltext-Prüfsummen nicht, Exit-Code 2.

Der dokumentierte Lauf verwendete PHP 8.5.12 mit `mbstring` und UTF-8. Seine vollständige, unveränderte Ausgabe steht in `quality-proof-run.txt`.

## Beispiel und Ergebnis

Das von der Anwendung definierte Schema verlangt:

- `status`: entweder `entwurf` oder `pruefung`.
- `description`: ein Text mit 1 bis 160 Zeichen.
- Beide Felder sind erforderlich; zusätzliche Felder sind nicht erlaubt.

| Eingabe | Tatsächliches Ergebnis von `validateJsonStrict()` |
| --- | --- |
| Erlaubter Status, Beschreibung mit 59 Zeichen | `true` |
| Status `veroeffentlicht` | `false` |
| Beschreibung mit 161 Zeichen | `false` |
| „Meldet euch bis 4. November zum TYPO3-Abend an.“ | `true` |

Für den letzten Fall lautet das Briefing: **„Wir laden zu einem TYPO3-Abend über KI ein. Ein Anmeldeschluss steht noch nicht fest.“** Der 4. November ist somit eine unbelegte Ergänzung. Die formalen Regeln erlauben den 47 Zeichen langen Satz trotzdem. Das Briefing wird im Beispiel bewusst zur fachlichen Einordnung gezeigt; es wird dem Validator nicht als Prüfregel übergeben. Die Erläuterungen in den Ergebnisdaten stammen aus diesem Beispiel. Der originale Validator gibt `true` oder `false` zurück, keine ausformulierte Fehlerdiagnose.

## Was daraus nicht folgt

Dieses Beispiel belegt weder automatische Faktenwarnungen im TYPO3-Backend noch das Verhalten einer bestimmten Landingpage-Demo. Es führt auch keine Modellgenerierung oder Reparatur aus. Der öffentliche Structured-Completion-Ablauf prüft ein unterstütztes, vom Aufrufer übergebenes Schema und kann eine ungültige Antwort einmal reparieren lassen; dessen Provideraufrufe sind hier nicht Teil des Tests.

Die direkt aufgerufenen Klassen sind **interne Implementierungsdetails** (`@internal`), keine empfohlene Integrationsschnittstelle für Extensions. Anwendungscode sollte die öffentliche `CompletionService`-API verwenden. Das strikte Schema bildet einen ausdrücklich dokumentierten Teilumfang von JSON Schema ab, keinen vollständigen JSON-Schema-Standard. Beispielsweise wird `format` nur als Annotation akzeptiert und nicht geprüft.

Eine fachlich verbindliche Frist muss aus einer verlässlichen Quelle kommen. Die Anwendung kann daraus eine konkrete erlaubte Wertemenge oder andere explizite Regel ableiten und prüfen; für frei formulierte Aussagen braucht es einen geeigneten Quellenvergleich und Prüfprozess.

## Quellen und Lizenz

Alle Links sind auf denselben geprüften Commit festgelegt:

- [Originaler JsonSchemaValidator](https://github.com/netresearch/t3x-nr-llm/blob/6afad3444ceb0ef3f206f6687df8d23eb881f496/Classes/Service/Schema/JsonSchemaValidator.php)
- [Originaler StrictSchemaSubset](https://github.com/netresearch/t3x-nr-llm/blob/6afad3444ceb0ef3f206f6687df8d23eb881f496/Classes/Service/Schema/StrictSchemaSubset.php)
- [Unterstützte Regeln, ADR-126](https://github.com/netresearch/t3x-nr-llm/blob/6afad3444ceb0ef3f206f6687df8d23eb881f496/Documentation/Adr/Adr126StrictSchemaSubset.rst)
- [Öffentliche CompletionService-API](https://github.com/netresearch/t3x-nr-llm/blob/6afad3444ceb0ef3f206f6687df8d23eb881f496/Documentation/Api/CompletionService.rst)

Originale Klassen: Copyright (c) 2025–2026 Netresearch DTT GmbH, **GPL-2.0-or-later**. Ihre Copyright- und Lizenzhinweise bleiben unverändert; der vollständige Lizenztext liegt in `quality-proof-source/LICENSE`. Das ausführbare Beispiel steht ebenfalls unter GPL-2.0-or-later. Bei Weitergabe das gesamte Beispiel einschließlich Originalquellen, Lizenz und Herkunftsnachweis zusammenhalten.
